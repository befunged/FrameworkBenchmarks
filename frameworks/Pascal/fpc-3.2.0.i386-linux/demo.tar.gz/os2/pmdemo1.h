/*******************************************

  Header f�r den Ressourcecompiler

********************************************/
#define ID_ClientWindow	1
